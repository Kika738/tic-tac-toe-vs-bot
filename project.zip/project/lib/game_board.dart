import 'package:flutter/material.dart';
import 'models/game_state.dart';
import 'widgets/game_cell.dart';
import 'widgets/game_status.dart';
import 'game_logic.dart';

class GameBoard extends StatefulWidget {
  const GameBoard({super.key});

  @override
  GameBoardState createState() => GameBoardState();
}

class GameBoardState extends State<GameBoard> {
  late GameState gameState;

  @override
  void initState() {
    super.initState();
    gameState = GameState.initial();
  }

  void resetGame() {
    setState(() {
      gameState = GameState.initial();
    });
  }

  void makeMove(int index) {
    if (gameState.board[index] != '' || 
        gameState.gameOver || 
        !gameState.isPlayerTurn) return;

    List<String> newBoard = List.from(gameState.board);
    newBoard[index] = 'X';

    setState(() {
      gameState = gameState.copyWith(
        board: newBoard,
        isPlayerTurn: false,
      );

      if (GameLogic.checkWinner(newBoard, 'X')) {
        gameState = gameState.copyWith(
          gameOver: true,
          winner: 'You win!',
        );
        return;
      }

      if (GameLogic.isBoardFull(newBoard)) {
        gameState = gameState.copyWith(
          gameOver: true,
          winner: 'Draw!',
        );
        return;
      }
    });

    // Bot's turn
    Future.delayed(const Duration(milliseconds: 500), () {
      if (!gameState.gameOver) {
        makeBotMove();
      }
    });
  }

  void makeBotMove() {
    int move = GameLogic.getBotMove(gameState.board);
    List<String> newBoard = List.from(gameState.board);
    newBoard[move] = 'O';

    setState(() {
      gameState = gameState.copyWith(
        board: newBoard,
        isPlayerTurn: true,
      );

      if (GameLogic.checkWinner(newBoard, 'O')) {
        gameState = gameState.copyWith(
          gameOver: true,
          winner: 'Bot wins!',
        );
        return;
      }

      if (GameLogic.isBoardFull(newBoard)) {
        gameState = gameState.copyWith(
          gameOver: true,
          winner: 'Draw!',
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tic Tac Toe'),
        centerTitle: true,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          GameStatus(
            gameOver: gameState.gameOver,
            winner: gameState.winner,
            isPlayerTurn: gameState.isPlayerTurn,
          ),
          const SizedBox(height: 20),
          GridView.builder(
            shrinkWrap: true,
            padding: const EdgeInsets.all(20),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
            ),
            itemCount: 9,
            itemBuilder: (context, index) {
              return GameCell(
                value: gameState.board[index],
                onTap: () => makeMove(index),
              );
            },
          ),
          const SizedBox(height: 20),
          if (gameState.gameOver)
            ElevatedButton(
              onPressed: resetGame,
              child: const Text('Play Again'),
            ),
        ],
      ),
    );
  }
}