import 'package:flutter/material.dart';

class GameStatus extends StatelessWidget {
  final bool gameOver;
  final String winner;
  final bool isPlayerTurn;

  const GameStatus({
    super.key,
    required this.gameOver,
    required this.winner,
    required this.isPlayerTurn,
  });

  @override
  Widget build(BuildContext context) {
    return Text(
      gameOver ? winner : (isPlayerTurn ? 'Your turn' : 'Bot thinking...'),
      style: const TextStyle(fontSize: 24),
    );
  }
}