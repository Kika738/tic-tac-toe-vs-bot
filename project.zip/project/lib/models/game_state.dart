class GameState {
  final List<String> board;
  final bool isPlayerTurn;
  final bool gameOver;
  final String winner;

  const GameState({
    required this.board,
    required this.isPlayerTurn,
    required this.gameOver,
    required this.winner,
  });

  GameState copyWith({
    List<String>? board,
    bool? isPlayerTurn,
    bool? gameOver,
    String? winner,
  }) {
    return GameState(
      board: board ?? this.board,
      isPlayerTurn: isPlayerTurn ?? this.isPlayerTurn,
      gameOver: gameOver ?? this.gameOver,
      winner: winner ?? this.winner,
    );
  }

  static GameState initial() {
    return GameState(
      board: List.filled(9, ''),
      isPlayerTurn: true,
      gameOver: false,
      winner: '',
    );
  }
}