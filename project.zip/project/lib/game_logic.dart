import 'dart:math';
import 'models/game_state.dart';

class GameLogic {
  static bool checkWinner(List<String> board, String player) {
    // Check rows
    for (int i = 0; i < 9; i += 3) {
      if (board[i] == player &&
          board[i + 1] == player &&
          board[i + 2] == player) {
        return true;
      }
    }

    // Check columns
    for (int i = 0; i < 3; i++) {
      if (board[i] == player &&
          board[i + 3] == player &&
          board[i + 6] == player) {
        return true;
      }
    }

    // Check diagonals
    if (board[0] == player && board[4] == player && board[8] == player) {
      return true;
    }
    if (board[2] == player && board[4] == player && board[6] == player) {
      return true;
    }

    return false;
  }

  static bool isBoardFull(List<String> board) {
    return !board.contains('');
  }

  static int? findWinningMove(List<String> board, String player) {
    for (int i = 0; i < board.length; i++) {
      if (board[i] == '') {
        List<String> tempBoard = List.from(board);
        tempBoard[i] = player;
        if (checkWinner(tempBoard, player)) {
          return i;
        }
      }
    }
    return null;
  }

  static int getBotMove(List<String> board) {
    int? winningMove = findWinningMove(board, 'O');
    int? blockingMove = findWinningMove(board, 'X');
    
    if (winningMove != null) return winningMove;
    if (blockingMove != null) return blockingMove;

    List<int> availableMoves = [];
    for (int i = 0; i < board.length; i++) {
      if (board[i] == '') {
        availableMoves.add(i);
      }
    }
    return availableMoves[Random().nextInt(availableMoves.length)];
  }
}